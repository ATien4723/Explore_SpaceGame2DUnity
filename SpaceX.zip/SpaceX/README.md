# Space-Rescue
A short space-based game where the player controls a Space Craft destroying or avoiding obstacles to get to the Goal Planet. This was a personal project to learn about Unity 2D Game Engine. The game has 3 Levels which get increasingly difficult. Although the game is playable it is far from its final state as I am still adding features in it.
